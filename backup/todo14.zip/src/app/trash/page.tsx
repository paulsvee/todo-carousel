"use client";

/* Paulsvee To do — Trash (React state 기반, 싱글톤 제거) */

import React, { useEffect, useState, useCallback } from "react";
import TopNav from "@/components/TopNav";
import type { TrashPanel } from "@/types/trashPanel";
import type { DoneTask } from "@/types/doneTask";

const STORAGE_KEY_TRASH = "paulsvee_todo_trash_v1";
const DEFAULT_PANEL_COLOR = "#7c98ff";

const formatStampIso = (iso: string) => {
  const d = new Date(iso);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}.${dd} ${hh}:${mi}`;
};

function loadFromStorage(): TrashPanel[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_TRASH);
    if (!raw) return [];
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.panels)) return [];
    const legacy = new Set(["#9ca3af", "#6b7280", "#4b5563"]);
    return data.panels.map((p: any): TrashPanel | null => {
      if (!p) return null;
      const items: DoneTask[] = (Array.isArray(p.items) ? p.items : [])
        .map((t: any): DoneTask | null => {
          if (!t) return null;
          return {
            id: typeof t.id === "string" ? t.id : crypto.randomUUID(),
            title: typeof t.title === "string" ? t.title : "",
            createdAt: typeof t.createdAt === "string" ? t.createdAt : new Date().toISOString(),
            doneAt: typeof t.doneAt === "string" ? t.doneAt : new Date().toISOString(),
            categoryName: typeof t.categoryName === "string" ? t.categoryName : "",
            originPanelTitle: typeof t.originPanelTitle === "string" ? t.originPanelTitle : "",
          };
        }).filter(Boolean) as DoneTask[];
      const rawColor = typeof p.color === "string" ? p.color : DEFAULT_PANEL_COLOR;
      return {
        id: typeof p.id === "string" ? p.id : crypto.randomUUID(),
        title: typeof p.title === "string" ? p.title : "000000-000000",
        fromDate: typeof p.fromDate === "string" ? p.fromDate : (items[0]?.createdAt ?? new Date().toISOString()),
        toDate: typeof p.toDate === "string" ? p.toDate : (items[0]?.createdAt ?? new Date().toISOString()),
        color: legacy.has(rawColor.toLowerCase()) ? DEFAULT_PANEL_COLOR : rawColor,
        items,
        isCollapsed: !!p.isCollapsed,
        isTitleCustom: !!p.isTitleCustom,
      };
    }).filter(Boolean) as TrashPanel[];
  } catch { return []; }
}

function saveToStorage(panels: TrashPanel[]) {
  try { localStorage.setItem(STORAGE_KEY_TRASH, JSON.stringify({ panels })); } catch {}
}

export default function TrashPage() {
  const [hydrated, setHydrated] = useState(false);
  const [panels, setPanels] = useState<TrashPanel[]>([]);
  const [undo, setUndo] = useState<TrashPanel[][]>([]);
  const [toast, setToast] = useState<string | null>(null);

  // 마운트 시 딱 한 번 로드
  useEffect(() => {
    setPanels(loadFromStorage());
    setHydrated(true);
  }, []);

  // panels 바뀔 때마다 저장
  useEffect(() => {
    if (!hydrated) return;
    saveToStorage(panels);
  }, [panels, hydrated]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 900);
  }, []);

  const pushUndo = useCallback((next: TrashPanel[]) => {
    setUndo((prev) => [panels, ...prev].slice(0, 20));
    setPanels(next);
  }, [panels]);

  const doUndo = () => {
    setUndo((prev) => {
      if (!prev.length) return prev;
      const [top, ...rest] = prev;
      setPanels(top);
      showToast("되돌림 완료");
      return rest;
    });
  };

  const setPanelTitle = (id: string, title: string) =>
    pushUndo(panels.map((p) => p.id === id ? { ...p, title, isTitleCustom: true } : p));

  const setPanelColor = (id: string, color: string) =>
    pushUndo(panels.map((p) => p.id === id ? { ...p, color } : p));

  const toggleCollapse = (id: string) =>
    pushUndo(panels.map((p) => p.id === id ? { ...p, isCollapsed: !p.isCollapsed } : p));

  const deleteItem = (panelId: string, itemId: string) => {
    const next = panels
      .map((p) => p.id === panelId ? { ...p, items: p.items.filter((it) => it.id !== itemId) } : p)
      .filter((p) => p.items.length > 0);
    pushUndo(next);
    showToast("삭제됨 (되돌림 가능)");
  };

  if (!hydrated) return (
    <main className="app">
      <div className="topbar"><div className="titleBlock"><div className="skeletonTitle"/><div className="skeletonSub"/></div></div>
    </main>
  );

  const totalItems = panels.reduce((acc, p) => acc + p.items.length, 0);

  return (
    <main className="app">
      <TopNav
        current="trash"
        titleValue="휴지통"
        mottoValue={`완료된 업무 히스토리 (삭제 아님) · 총 패널 ${panels.length} · 총 항목 ${totalItems}`}
        titleReadOnly mottoReadOnly
        onChangeTitle={() => {}} onChangeMotto={() => {}}
      >
        <button className="iconBtn" onClick={doUndo} disabled={undo.length === 0} title="되돌림" aria-label="Undo">↶</button>
      </TopNav>

      <section className="panelRow trashPanelRow" aria-label="Trash panels">
        {panels.length === 0 ? (
          <article className="panel" style={{ ["--panel" as any]: DEFAULT_PANEL_COLOR }}>
            <header className="panelHeader">
              <div className="panelTitleWrap">
                <span className="dot" />
                <input className="panelTitle" value="완료 기록 없음" readOnly />
              </div>
              <div className="panelRight">
                <span className="itemMeta" style={{ opacity: 0.7 }}>아직 이동된 항목이 없어요.</span>
              </div>
            </header>
          </article>
        ) : panels.map((p) => {
          const sorted = [...p.items].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          return (
            <article key={p.id} className="panel trashPanel" style={{ ["--panel" as any]: p.color }}>
              <header className="panelHeader">
                <div className="panelTitleWrap">
                  <span className="dot" />
                  <input className="panelTitle" value={p.title}
                    onChange={(e) => setPanelTitle(p.id, e.target.value)}
                    style={{ fontSize: 14, fontWeight: 700 }} />
                </div>
                <div className="panelRight">
                  <label className="colorPill" title="패널 색상">
                    <input type="color" className="colorInput" value={p.color}
                      onChange={(e) => setPanelColor(p.id, e.target.value)} />
                  </label>
                  <button className="iconBtn" type="button"
                    title={p.isCollapsed ? "펼치기" : "접기"}
                    onClick={() => toggleCollapse(p.id)}>
                    {p.isCollapsed ? "▾" : "▴"}
                  </button>
                  <span className="itemMeta" style={{ opacity: 0.85 }}>{p.items.length}개</span>
                </div>
              </header>

              <div className="panelTools" />

              {!p.isCollapsed && (
                <ul className="list">
                  {sorted.map((it, idx) => (
                    <li key={it.id} className="item">
                      <button className="itemGrab" aria-label="history">•</button>
                      <div className="itemMain">
                        <input className="itemText" value={`${sorted.length - idx}. ${it.title}`} readOnly />
                        {it.categoryName && (
                          <span className="trashItemCat">{it.categoryName}</span>
                        )}
                      </div>
                      <div className="itemMeta">{formatStampIso(it.createdAt)}</div>
                      <button className="xBtn" type="button" title="완료 기록 삭제"
                        onClick={() => deleteItem(p.id, it.id)}>×</button>
                    </li>
                  ))}
                </ul>
              )}
            </article>
          );
        })}
      </section>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}
