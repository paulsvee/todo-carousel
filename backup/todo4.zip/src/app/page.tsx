"use client";

/* Paulsvee To do — v5.6 (TopNav + P button) */

import React, { useEffect, useRef, useState } from "react";
import { addDoneTaskToTrash } from "@/store/trashStore";
import TopNav from "@/components/TopNav";

type TodoItem = {
  id: string;
  text: string;
  done: boolean;
  createdAt: number; // epoch ms
};

type Panel = {
  id: string;
  title: string;
  color: string; // hex
  createdAt: number;
  items: TodoItem[];

  isSpecial?: boolean;
  bgImage?: string | null; // dataURL
};

type AppState = {
  version: 2;
  appTitle: string;
  motto: string;
  panels: Panel[];
};

const STORAGE_KEY_V2 = "paulsvee_todo_carousel_v2";
const STORAGE_KEY_V1 = "paulsvee_todo_carousel_v1";

/** -------- utils -------- */
const uid = () =>
  globalThis.crypto?.randomUUID?.() ?? `id_${Math.random().toString(16).slice(2)}_${Date.now()}`;

const clampText = (s: string) => s.replace(/\s+/g, " ").trim();

const formatStamp = (ms: number) => {
  const d = new Date(ms);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}.${dd} ${hh}:${mi}`;
};

/** 스페셜 패널: 항목 텍스트에서 "라벨: 숫자" 패턴을 찾아 합산 */
const extractPanelSum = (items: TodoItem[]): number | null => {
  let total = 0;
  let found = false;
  for (const item of items) {
    // "어떤텍스트: 1,234,567" 또는 "어떤텍스트: 1234" 형식 (콜론 뒤 숫자)
    const m = item.text.match(/:\s*([\d,]+)\s*$/);
    if (m) {
      const n = parseInt(m[1].replace(/,/g, ""), 10);
      if (!isNaN(n)) {
        total += n;
        found = true;
      }
    }
  }
  return found ? total : null;
};

const formatNumber = (n: number) => n.toLocaleString("ko-KR");

const seedState = (): AppState => ({
  version: 2,
  appTitle: "Paulsvee To do",
  motto: "",
  panels: [
    {
      id: uid(),
      title: "패널",
      color: "#e45b70",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: `주의 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 60_000,
      })),
    },
    {
      id: uid(),
      title: "수익",
      color: "#7c98ff",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: i === 0 ? "수익 항목" : `수익 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 70_000,
      })),
    },
    {
      id: uid(),
      title: "성경",
      color: "#f0d05a",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: `성경 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 80_000,
      })),
    },
  ],
});

function safeParseState(raw: string | null): AppState | null {
  if (!raw) return null;
  try {
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return null;

    const appTitle = typeof (data as any).appTitle === "string" ? (data as any).appTitle : "Paulsvee To do";
    const motto = typeof (data as any).motto === "string" ? (data as any).motto : "";

    const panelsIn = Array.isArray((data as any).panels) ? (data as any).panels : [];
    const panels: Panel[] = panelsIn
      .map((p: any) => {
        if (!p) return null;
        const itemsIn = Array.isArray(p.items) ? p.items : [];
        const items: TodoItem[] = itemsIn
          .map((t: any) => {
            if (!t) return null;
            return {
              id: typeof t.id === "string" ? t.id : uid(),
              text: typeof t.text === "string" ? t.text : "",
              done: !!t.done,
              createdAt: typeof t.createdAt === "number" ? t.createdAt : Date.now(),
            };
          })
          .filter(Boolean) as TodoItem[];

        return {
          id: typeof p.id === "string" ? p.id : uid(),
          title: typeof p.title === "string" ? p.title : "패널",
          color: typeof p.color === "string" ? p.color : "#7c98ff",
          createdAt: typeof p.createdAt === "number" ? p.createdAt : Date.now(),
          items,
          isSpecial: typeof p.isSpecial === "boolean" ? p.isSpecial : false,
          bgImage: typeof p.bgImage === "string" ? p.bgImage : null,
        };
      })
      .filter(Boolean) as Panel[];

    return { version: 2, appTitle, motto, panels };
  } catch {
    return null;
  }
}

/** Debounced localStorage save (stops jank/freezes) */
function useDebouncedLocalStorage(state: AppState) {
  const latest = useRef(state);
  latest.current = state;

  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(latest.current));
      } catch {
        // ignore quota / private mode
      }
    }, 220);
    return () => window.clearTimeout(t);
  }, [state]);
}

/** Undo stack */
type UndoEntry = AppState;
const MAX_UNDO = 20;

export default function Page() {
  const [hydrated, setHydrated] = useState(false);
  const [state, setState] = useState<AppState>(() => seedState());
  const [undo, setUndo] = useState<UndoEntry[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  // DnD (panel)
  const dragPanelId = useRef<string | null>(null);

  // DnD (item)
  const dragItem = useRef<{ panelId: string; itemId: string } | null>(null);
  const [dropHint, setDropHint] = useState<{ panelId: string; beforeItemId: string | null } | null>(null);
  // Special panel: file inputs (per panel)
  const specialInputRefs = useRef<Record<string, HTMLInputElement | null>>({});


  useEffect(() => {
    const loaded = safeParseState(localStorage.getItem(STORAGE_KEY_V2)) || safeParseState(localStorage.getItem(STORAGE_KEY_V1));
    if (loaded) setState(loaded);
    setHydrated(true);
  }, []);

  useDebouncedLocalStorage(state);

  const pushUndo = (next: AppState) => {
    setUndo((prev) => [state, ...prev].slice(0, MAX_UNDO));
    setState(next);
  };

  const doUndo = () => {
    setUndo((prev) => {
      if (prev.length === 0) return prev;
      const [top, ...rest] = prev;
      setState(top);
      setToast("되돌림 완료");
      window.setTimeout(() => setToast(null), 900);
      return rest;
    });
  };

  const panels = state.panels;

  const updateTitle = (v: string) => pushUndo({ ...state, appTitle: v });
  const updateMotto = (v: string) => pushUndo({ ...state, motto: v });

  // ✅ P 버튼: 기본 패널명 "P" (나중에 필요하면 자동 넘버링으로 확장)
  const addPanel = () => {
    const next: Panel = {
      id: uid(),
      title: "P",
      color: "#7c98ff",
      createdAt: Date.now(),
      items: [],
    };
    pushUndo({ ...state, panels: [...panels, next] });
  };

  const addSpecialPanel = () => {
    const next: Panel = {
      id: uid(),
      title: "Special",
      color: "#7c98ff",
      createdAt: Date.now(),
      items: [],
      isSpecial: true,
      bgImage: null,
    };
    pushUndo({ ...state, panels: [...panels, next] });
    setToast("스페셜 패널 추가됨");
    window.setTimeout(() => setToast(null), 1200);
  };

  const setPanelBgImage = (panelId: string, dataUrl: string | null) => {
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId ? { ...p, isSpecial: true, bgImage: dataUrl } : p
      ),
    });
  };

  const onPickPanelImage = (panelId: string, file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : null;
      if (!dataUrl) return;
      setPanelBgImage(panelId, dataUrl);
      setToast("배경 이미지 설정됨");
      window.setTimeout(() => setToast(null), 1200);
    };
    reader.readAsDataURL(file);
  };

  const clearPanelImage = (panelId: string) => {
    setPanelBgImage(panelId, null);
    const el = specialInputRefs.current[panelId];
    if (el) el.value = "";
    setToast("배경 이미지 제거됨");
    window.setTimeout(() => setToast(null), 1200);
  };


  const deletePanel = (panelId: string) => {
    pushUndo({ ...state, panels: panels.filter((p) => p.id !== panelId) });
    setToast("패널 삭제됨 (되돌림 가능)");
    window.setTimeout(() => setToast(null), 1400);
  };

  const setPanelColor = (panelId: string, color: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) => (p.id === panelId ? { ...p, color } : p)),
    });
  };

  const renamePanel = (panelId: string, title: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) => (p.id === panelId ? { ...p, title } : p)),
    });
  };

  const addItem = (panelId: string, text: string) => {
    const t = clampText(text);
    if (!t) return;
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId
          ? {
              ...p,
              items: [{ id: uid(), text: t, done: false, createdAt: Date.now() }, ...p.items],
            }
          : p
      ),
    });
  };

  const updateItemText = (panelId: string, itemId: string, text: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId ? { ...p, items: p.items.map((it) => (it.id === itemId ? { ...it, text } : it)) } : p
      ),
    });
  };

  // ✅ 체크해서 done 되면: 휴지통으로 이동(리스트에서 제거)
  const toggleItem = (panelId: string, itemId: string) => {
    const p = panels.find((x) => x.id === panelId);
    const it = p?.items.find((x) => x.id === itemId);
    if (!p || !it) return;

    const goingDone = !it.done;

    if (goingDone) {
      addDoneTaskToTrash({
        id: it.id,
        title: it.text,
        categoryId: p.id,
        categoryName: p.title,
        originPanelTitle: p.title,
        createdAt: new Date(it.createdAt).toISOString(),
        doneAt: new Date().toISOString(),
      });

      pushUndo({
        ...state,
        panels: panels.map((px) => (px.id === panelId ? { ...px, items: px.items.filter((x) => x.id !== itemId) } : px)),
      });

      setToast("휴지통으로 이동");
      window.setTimeout(() => setToast(null), 900);
      return;
    }

    // (원칙상 done 항목은 남아있지 않지만, 데이터가 남아있는 경우 대비)
    pushUndo({
      ...state,
      panels: panels.map((px) =>
        px.id === panelId ? { ...px, items: px.items.map((x) => (x.id === itemId ? { ...x, done: !x.done } : x)) } : px
      ),
    });
  };

  const deleteItem = (panelId: string, itemId: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) => (p.id === panelId ? { ...p, items: p.items.filter((it) => it.id !== itemId) } : p)),
    });
    setToast("항목 삭제됨 (되돌림 가능)");
    window.setTimeout(() => setToast(null), 1400);
  };

  /** -------- DnD: Panels -------- */
  const onPanelDragStart = (id: string) => {
    dragPanelId.current = id;
  };

  const onPanelDrop = (targetId: string) => {
    const fromId = dragPanelId.current;
    dragPanelId.current = null;
    if (!fromId || fromId === targetId) return;

    const fromIdx = panels.findIndex((p) => p.id === fromId);
    const toIdx = panels.findIndex((p) => p.id === targetId);
    if (fromIdx < 0 || toIdx < 0) return;

    const next = [...panels];
    const [moved] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, moved);

    pushUndo({ ...state, panels: next });
  };

  /** -------- DnD: Items (within same panel) -------- */
  const reorderItem = (panelId: string, itemId: string, beforeItemId: string | null) => {
    const p = panels.find((x) => x.id === panelId);
    if (!p) return;
    const fromIdx = p.items.findIndex((x) => x.id === itemId);
    if (fromIdx < 0) return;

    const items = [...p.items];
    const [moved] = items.splice(fromIdx, 1);

    let toIdx = beforeItemId ? items.findIndex((x) => x.id === beforeItemId) : items.length;
    if (toIdx < 0) toIdx = items.length;
    items.splice(toIdx, 0, moved);

    pushUndo({ ...state, panels: panels.map((x) => (x.id === panelId ? { ...x, items } : x)) });
  };

  const onItemDragStart = (panelId: string, itemId: string) => {
    dragItem.current = { panelId, itemId };
  };

  const onItemDragOver = (panelId: string, beforeItemId: string | null) => {
    const cur = dragItem.current;
    if (!cur) return;
    if (cur.panelId !== panelId) return;
    setDropHint({ panelId, beforeItemId });
  };

  const onItemDrop = (panelId: string, beforeItemId: string | null) => {
    const cur = dragItem.current;
    dragItem.current = null;
    setDropHint(null);
    if (!cur) return;
    if (cur.panelId !== panelId) return;
    reorderItem(panelId, cur.itemId, beforeItemId);
  };

  const onItemDragEnd = () => {
    dragItem.current = null;
    setDropHint(null);
  };

  /** -------- render -------- */
  if (!hydrated) {
    return (
      <main className="app">
        <div className="topbar">
          <div className="titleBlock">
            <div className="skeletonTitle" />
            <div className="skeletonSub" />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="app">
      <TopNav
        current="main"
        titleValue={state.appTitle}
        mottoValue={state.motto}
        onChangeTitle={updateTitle}
        onChangeMotto={updateMotto}
      >
        <button className="iconBtn" onClick={doUndo} disabled={undo.length === 0} title="되돌림" aria-label="되돌림">
          ↶
        </button>

        <button className="primaryBtn" onClick={addPanel} aria-label="Add panel" title="패널 추가">
          P
        </button>

        <button className="primaryBtn" onClick={addSpecialPanel} aria-label="Add special panel" title="스페셜 패널">
          S
        </button>
      </TopNav>

      <section className="panelRow" aria-label="Panels">
        {panels.map((p) => (
          <article
            key={p.id}
            className="panel"
            style={{
              ["--panel" as any]: p.color,
              position: "relative",
              ...(p.bgImage
                ? {
                    backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0.62), rgba(0,0,0,0.62)), url(${p.bgImage})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",
                  }
                : {}),
            }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onPanelDrop(p.id)}
          >
            <header className="panelHeader">
              <div className="panelTitleWrap">
                <span className="dot" />
                <input className="panelTitle" value={p.title} onChange={(e) => renamePanel(p.id, e.target.value)} />
              </div>

              <div className="panelRight">
                <button
                  className="grabBtn"
                  draggable
                  onDragStart={() => onPanelDragStart(p.id)}
                  title="패널 이동"
                  aria-label="패널 이동"
                >
                  ⠿
                </button>

                <label className="colorPill" title="패널 색상">
                  <input
                    type="color"
                    className="colorInput"
                    value={p.color}
                    onChange={(e) => setPanelColor(p.id, e.target.value)}
                  />
                </label>

                <button className="dangerBtn" onClick={() => deletePanel(p.id)} title="패널 삭제" aria-label="패널 삭제">
                  X
                </button>
              </div>
            </header>

            <div className="panelTools">
              {p.isSpecial ? (
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                  <label
                    className="secondaryBtn"
                    title="이미지 첨부"
                    style={{
                      height: 34,
                      padding: "0 14px",
                      borderRadius: 999,
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      lineHeight: 1,
                      cursor: "pointer",
                    }}
                  >
                    img
                    <input
                      type="file"
                      accept="image/*"
                      style={{ display: "none" }}
                      ref={(el) => {
                        specialInputRefs.current[p.id] = el;
                      }}
                      onChange={(e) => onPickPanelImage(p.id, e.currentTarget.files?.[0] ?? null)}
                    />
                  </label>
                  {p.bgImage ? (
                    <button
                      className="dangerBtn"
                      title="배경 이미지 삭제"
                      aria-label="Remove background image"
                      onClick={() => clearPanelImage(p.id)}
                      style={{ width: 34, height: 34 }}
                    >
                      ×
                    </button>
                  ) : null}
                </div>
              ) : null}

              <TodoComposer onAdd={(t) => addItem(p.id, t)} />
            </div>

            <ul className="list" aria-label={`${p.title} items`}>
              {p.items.map((it) => {
                const hintHere = dropHint?.panelId === p.id && dropHint?.beforeItemId === it.id;

                return (
                  <React.Fragment key={it.id}>
                    {hintHere && <div className="dropLine" />}
                    <li
                      className={`item ${it.done ? "done" : ""}`}
                      draggable
                      onDragStart={() => onItemDragStart(p.id, it.id)}
                      onDragOver={(e) => {
                        e.preventDefault();
                        onItemDragOver(p.id, it.id);
                      }}
                      onDrop={() => onItemDrop(p.id, it.id)}
                      onDragEnd={onItemDragEnd}
                    >
                      <button className="itemGrab" title="드래그로 이동" aria-label="drag handle">
                        ⋮⋮
                      </button>

                      <input
                        className="chk"
                        type="checkbox"
                        checked={it.done}
                        onChange={() => toggleItem(p.id, it.id)}
                        aria-label="done"
                      />

                      <div className="itemMain">
                        <input
                          className={`itemText${it.done ? " done" : ""}`}
                          value={it.text}
                          onChange={(e) => updateItemText(p.id, it.id, e.target.value)}
                        />
                      </div>

                      <div className="itemMeta">{formatStamp(it.createdAt)}</div>

                      <button className="xBtn" onClick={() => deleteItem(p.id, it.id)} title="삭제" aria-label="삭제">
                        ×
                      </button>
                    </li>
                  </React.Fragment>
                );
              })}

              {/* drop at end */}
              {dropHint?.panelId === p.id && dropHint?.beforeItemId === null && <div className="dropLine" />}
              <li
                className="endDropZone"
                onDragOver={(e) => {
                  e.preventDefault();
                  onItemDragOver(p.id, null);
                }}
                onDrop={() => onItemDrop(p.id, null)}
              />
            </ul>

            {/* 스페셜 패널 합계 바: 콜론+숫자 항목이 하나라도 있을 때 표시 */}
            {p.isSpecial && (() => {
              const sum = extractPanelSum(p.items);
              if (sum === null) return null;
              return (
                <div className="sumBar">
                  <span className="sumLabel">합계</span>
                  <span className="sumValue">{formatNumber(sum)}</span>
                </div>
              );
            })()}
          </article>
        ))}
      </section>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}

function TodoComposer({ onAdd }: { onAdd: (text: string) => void }) {
  const [v, setV] = useState("");
  return (
    <div className="composer">
      <input
        className="todoInput"
        value={v}
        placeholder="할 일 입력 후 Enter"
        onChange={(e) => setV(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            onAdd(v);
            setV("");
          }
        }}
      />
      <button
        className="secondaryBtn"
        onClick={() => {
          onAdd(v);
          setV("");
        }}
      >
        추가
      </button>
    </div>
  );
}
