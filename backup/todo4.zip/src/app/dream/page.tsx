"use client";

/* Paulsvee To do — v5.5 (Dream page - identical to main, separate storage) */

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";

type TodoItem = {
  id: string;
  text: string;
  done: boolean;
  createdAt: number; // epoch ms
};

type Panel = {
  id: string;
  title: string;
  color: string; // hex
  createdAt: number;
  items: TodoItem[];
  // Dream-only extensions
  isSpecial?: boolean;
  bgImage?: string | null; // dataURL
};

type AppState = {
  version: 2;
  appTitle: string;
  motto: string;
  panels: Panel[];
};

const STORAGE_KEY_V2 = "paulsvee_todo_carousel_dream_v2";
const STORAGE_KEY_V1 = "paulsvee_todo_carousel_dream_v1";

/** -------- utils -------- */
const uid = () =>
  (globalThis.crypto?.randomUUID?.() ?? `id_${Math.random().toString(16).slice(2)}_${Date.now()}`);

const clampText = (s: string) => s.replace(/\s+/g, " ").trim();

const formatStamp = (ms: number) => {
  const d = new Date(ms);
  // 짧게: 02.03 14:44
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}.${dd} ${hh}:${mi}`;
};

// simple hex color mixer (for inline styles without relying on color-mix())
const mixHex = (hexA: string, hexB: string, t: number) => {
  const clamp = (n: number) => Math.max(0, Math.min(1, n));
  const tt = clamp(t);
  const parse = (h: string) => {
    const s = (h || "#000000").replace("#", "").trim();
    const full = s.length === 3 ? s.split("").map((c) => c + c).join("") : s;
    const n = Number.parseInt(full || "000000", 16);
    return {
      r: (n >> 16) & 255,
      g: (n >> 8) & 255,
      b: n & 255,
    };
  };
  const a = parse(hexA);
  const b = parse(hexB);
  const r = Math.round(a.r * (1 - tt) + b.r * tt);
  const g = Math.round(a.g * (1 - tt) + b.g * tt);
  const bl = Math.round(a.b * (1 - tt) + b.b * tt);
  return `rgb(${r} ${g} ${bl})`;
};


const rgbaFromHex = (hex: string, a: number) => {
  const h = hex.replace("#", "").trim();
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h.padEnd(6, "0").slice(0, 6);
  const r = parseInt(full.slice(0, 2), 16) || 0;
  const g = parseInt(full.slice(2, 4), 16) || 0;
  const b = parseInt(full.slice(4, 6), 16) || 0;
  return `rgba(${r}, ${g}, ${b}, ${a})`;
};

const Dots6 = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden="true">
    <circle cx="3" cy="3" r="1" fill="currentColor" />
    <circle cx="6" cy="3" r="1" fill="currentColor" />
    <circle cx="9" cy="3" r="1" fill="currentColor" />
    <circle cx="3" cy="7" r="1" fill="currentColor" />
    <circle cx="6" cy="7" r="1" fill="currentColor" />
    <circle cx="9" cy="7" r="1" fill="currentColor" />
  </svg>
);

const CheckMark = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden="true">
    <path
      d="M3.4 8.6l2.7 2.7L12.8 4.6"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/** 스페셜 패널: 항목 텍스트에서 "라벨: 숫자" 패턴을 찾아 합산 */
const extractPanelSum = (items: TodoItem[]): number | null => {
  let total = 0;
  let found = false;
  for (const item of items) {
    const m = item.text.match(/:\s*([\d,]+)\s*$/);
    if (m) {
      const n = parseInt(m[1].replace(/,/g, ""), 10);
      if (!isNaN(n)) { total += n; found = true; }
    }
  }
  return found ? total : null;
};

const formatNumber = (n: number) => n.toLocaleString("ko-KR");

const seedState = (): AppState => ({
  version: 2,
  appTitle: "Paulsvee To do",
  motto: "",
  panels: [
    {
      id: uid(),
      title: "패널",
      color: "#e45b70",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: `주의 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 60_000,
      })),
    },
    {
      id: uid(),
      title: "수익",
      color: "#7c98ff",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: i === 0 ? "수익 항목" : `수익 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 70_000,
      })),
    },
    {
      id: uid(),
      title: "성경",
      color: "#f0d05a",
      createdAt: Date.now(),
      items: Array.from({ length: 5 }).map((_, i) => ({
        id: uid(),
        text: `성경 항목 예시 ${i + 1}`,
        done: false,
        createdAt: Date.now() - i * 80_000,
      })),
    },
  ],
});

function safeParseState(raw: string | null): AppState | null {
  if (!raw) return null;
  try {
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return null;

    // very lenient migration: if panels exist, accept and fill missing fields
    const appTitle = typeof (data as any).appTitle === "string" ? (data as any).appTitle : "Paulsvee To do";
    const motto = typeof (data as any).motto === "string" ? (data as any).motto : "";

    const panelsIn = Array.isArray((data as any).panels) ? (data as any).panels : [];
    const panels: Panel[] = panelsIn
      .map((p: any) => {
        if (!p) return null;
        const itemsIn = Array.isArray(p.items) ? p.items : [];
        const items: TodoItem[] = itemsIn
          .map((t: any) => {
            if (!t) return null;
            return {
              id: typeof t.id === "string" ? t.id : uid(),
              text: typeof t.text === "string" ? t.text : "",
              done: !!t.done,
              createdAt: typeof t.createdAt === "number" ? t.createdAt : Date.now(),
            };
          })
          .filter(Boolean) as TodoItem[];

        return {
          id: typeof p.id === "string" ? p.id : uid(),
          title: typeof p.title === "string" ? p.title : "패널",
          color: typeof p.color === "string" ? p.color : "#7c98ff",
          createdAt: typeof p.createdAt === "number" ? p.createdAt : Date.now(),
          isSpecial: !!(p as any).isSpecial,
          bgImage: typeof (p as any).bgImage === "string" ? (p as any).bgImage : null,
          items,
        };
      })
      .filter(Boolean) as Panel[];

    return { version: 2, appTitle, motto, panels };
  } catch {
    return null;
  }
}

/** Debounced localStorage save (stops jank/freezes) */
function useDebouncedLocalStorage(state: AppState) {
  const latest = useRef(state);
  latest.current = state;

  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(latest.current));
      } catch {
        // ignore quota / private mode
      }
    }, 220);
    return () => window.clearTimeout(t);
  }, [state]);
}

/** Undo stack (single step is enough, but keep a small stack) */
type UndoEntry = AppState;
const MAX_UNDO = 20;

export default function Page() {
  const [hydrated, setHydrated] = useState(false);
  const [state, setState] = useState<AppState>(() => seedState());
  const [undo, setUndo] = useState<UndoEntry[]>([]);
  const [toast, setToast] = useState<string | null>(null);

  // Special panel image inputs (so delete -> re-pick same file works)
  const specialInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  // DnD (panel)
  const dragPanelId = useRef<string | null>(null);

  // DnD (item)
  const dragItem = useRef<{ panelId: string; itemId: string } | null>(null);
  const [dropHint, setDropHint] = useState<{ panelId: string; beforeItemId: string | null } | null>(
    null
  );

  useEffect(() => {
    const loaded =
      safeParseState(localStorage.getItem(STORAGE_KEY_V2)) ||
      safeParseState(localStorage.getItem(STORAGE_KEY_V1));
    if (loaded) setState(loaded);
    setHydrated(true);
  }, []);

  useDebouncedLocalStorage(state);

  const pushUndo = (next: AppState) => {
    setUndo((prev) => [state, ...prev].slice(0, MAX_UNDO));
    setState(next);
  };

  const doUndo = () => {
    setUndo((prev) => {
      if (prev.length === 0) return prev;
      const [top, ...rest] = prev;
      setState(top);
      setToast("되돌림 완료");
      window.setTimeout(() => setToast(null), 900);
      return rest;
    });
  };

  const panels = state.panels;

  const updateTitle = (v: string) => {
    pushUndo({ ...state, appTitle: v });
  };

  const updateMotto = (v: string) => {
    pushUndo({ ...state, motto: v });
  };

  const addPanel = (title?: string) => {
    const name = clampText(title ?? "P");
    if (!name) return;
    const next: Panel = {
      id: uid(),
      title: name,
      color: "#7c98ff",
      createdAt: Date.now(),
      items: [],
    };
    pushUndo({ ...state, panels: [...panels, next] });
  };


  const addSpecialPanel = () => {
    const next: Panel = {
      id: uid(),
      title: "Special",
      color: "#7c98ff",
      createdAt: Date.now(),
      items: [],
      isSpecial: true,
      bgImage: null,
    };
    pushUndo({ ...state, panels: [...panels, next] });
    setToast("스페셜 패널 추가됨");
    window.setTimeout(() => setToast(null), 1200);
  };

  const deletePanel = (panelId: string) => {
    pushUndo({ ...state, panels: panels.filter((p) => p.id !== panelId) });
    setToast("패널 삭제됨 (되돌림 가능)");
    window.setTimeout(() => setToast(null), 1400);
  };

  const setPanelColor = (panelId: string, color: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) => (p.id === panelId ? { ...p, color } : p)),
    });
  };

  const renamePanel = (panelId: string, title: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) => (p.id === panelId ? { ...p, title } : p)),
    });
  };

  const setPanelBgImage = (panelId: string, dataUrl: string | null) => {
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId ? { ...p, isSpecial: true, bgImage: dataUrl } : p
      ),
    });
  };

  const onPickPanelImage = (panelId: string, file: File | null) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : null;
      if (!dataUrl) return;
      setPanelBgImage(panelId, dataUrl);
      setToast("배경 이미지 설정됨");
      window.setTimeout(() => setToast(null), 1200);
    };
    reader.readAsDataURL(file);
  };

  const clearPanelImage = (panelId: string) => {
    setPanelBgImage(panelId, null);
    const el = specialInputRefs.current[panelId];
    if (el) el.value = "";
    setToast("배경 이미지 제거됨");
    window.setTimeout(() => setToast(null), 1200);
  };

  const addItem = (panelId: string, text: string) => {
    const t = clampText(text);
    if (!t) return;
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId
          ? {
              ...p,
              items: [
                {
                  id: uid(),
                  text: t,
                  done: false,
                  createdAt: Date.now(),
                },
                ...p.items,
              ],
            }
          : p
      ),
    });
  };

  const updateItemText = (panelId: string, itemId: string, text: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId
          ? { ...p, items: p.items.map((it) => (it.id === itemId ? { ...it, text } : it)) }
          : p
      ),
    });
  };

  // ✅ 체크해서 done 되면: 휴지통으로 이동(리스트에서 제거)
  const toggleItem = (panelId: string, itemId: string) => {
    const p = panels.find((x) => x.id === panelId);
    const it = p?.items.find((x) => x.id === itemId);
    if (!p || !it) return;

    const nextDone = !it.done;

    pushUndo({
      ...state,
      panels: panels.map((px) =>
        px.id === panelId
          ? { ...px, items: px.items.map((x) => (x.id === itemId ? { ...x, done: nextDone } : x)) }
          : px
      ),
    });

    setToast(nextDone ? "이룸 표시" : "이룸 해제");
    window.setTimeout(() => setToast(null), 900);
  };

  const deleteItem = (panelId: string, itemId: string) => {
    pushUndo({
      ...state,
      panels: panels.map((p) =>
        p.id === panelId ? { ...p, items: p.items.filter((it) => it.id !== itemId) } : p
      ),
    });
    setToast("항목 삭제됨 (되돌림 가능)");
    window.setTimeout(() => setToast(null), 1400);
  };

  /** -------- DnD: Panels -------- */
  const onPanelDragStart = (id: string) => {
    dragPanelId.current = id;
  };

  const onPanelDrop = (targetId: string) => {
    const fromId = dragPanelId.current;
    dragPanelId.current = null;
    if (!fromId || fromId === targetId) return;

    const fromIdx = panels.findIndex((p) => p.id === fromId);
    const toIdx = panels.findIndex((p) => p.id === targetId);
    if (fromIdx < 0 || toIdx < 0) return;

    const next = [...panels];
    const [moved] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, moved);

    pushUndo({ ...state, panels: next });
  };

  /** -------- DnD: Items (within same panel) -------- */
  const reorderItem = (panelId: string, itemId: string, beforeItemId: string | null) => {
    const p = panels.find((x) => x.id === panelId);
    if (!p) return;
    const fromIdx = p.items.findIndex((x) => x.id === itemId);
    if (fromIdx < 0) return;

    const items = [...p.items];
    const [moved] = items.splice(fromIdx, 1);

    let toIdx = beforeItemId ? items.findIndex((x) => x.id === beforeItemId) : items.length;
    if (toIdx < 0) toIdx = items.length;
    items.splice(toIdx, 0, moved);

    pushUndo({
      ...state,
      panels: panels.map((x) => (x.id === panelId ? { ...x, items } : x)),
    });
  };

  const onItemDragStart = (panelId: string, itemId: string) => {
    dragItem.current = { panelId, itemId };
  };

  const onItemDragOver = (panelId: string, beforeItemId: string | null) => {
    const cur = dragItem.current;
    if (!cur) return;
    if (cur.panelId !== panelId) return; // same panel only (simple & fast)
    setDropHint({ panelId, beforeItemId });
  };

  const onItemDrop = (panelId: string, beforeItemId: string | null) => {
    const cur = dragItem.current;
    dragItem.current = null;
    setDropHint(null);
    if (!cur) return;
    if (cur.panelId !== panelId) return;
    reorderItem(panelId, cur.itemId, beforeItemId);
  };

  const onItemDragEnd = () => {
    dragItem.current = null;
    setDropHint(null);
  };

  /** -------- render -------- */
  if (!hydrated) {
    return (
      <main className="app">
        <div className="topbar">
          <div className="titleBlock">
            <div className="skeletonTitle" />
            <div className="skeletonSub" />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="app">
      <div className="topbar">
        <div className="titleBlock">
          <input
            className="appTitle"
            value={state.appTitle}
            onChange={(e) => updateTitle(e.target.value)}
            aria-label="App title"
          />
          <input
            className="mottoInput"
            value={state.motto}
            onChange={(e) => updateMotto(e.target.value)}
            placeholder="좌우명 / 오늘 한 줄 메모 (클릭해서 수정)"
            aria-label="Motto"
          />
        </div>

        <div className="topActions">
          {/* ✅ 홈 */}
          <Link
            className="iconBtn"
            href="/"
            title="홈"
            aria-label="홈"
            style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1v-10.5Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>
          {/* ✅ 꿈 목록 */}
          <Link
            className="iconBtn"
            href="/dream"
            title="꿈 목록"
            aria-label="꿈 목록"
            // ✅ 현재 페이지 ON 표시(꿈)
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              borderColor: "rgba(255,255,255,0.28)",
              background: "rgba(255,255,255,0.12)",
              boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.06)",
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M20.5 14.2c-1.1.6-2.3.9-3.6.9-4.2 0-7.6-3.4-7.6-7.6 0-1.3.3-2.5.9-3.6C6.9 4.9 5 7.4 5 10.5 5 15.2 8.8 19 13.5 19c3.1 0 5.6-1.9 7-4.8Z"
                fill="currentColor"
                opacity="0.9"
              />
              <path
                d="M16.7 6.2l.6 1.7 1.7.6-1.7.6-.6 1.7-.6-1.7-1.7-.6 1.7-.6.6-1.7Z"
                fill="currentColor"
              />
            </svg>
          </Link>

          {/* ✅ 휴지통(완료 히스토리) */}
          <Link
            className="iconBtn"
            href="/trash"
            title="휴지통"
            aria-label="휴지통"
            style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M9 3h6m-8 4h10m-9 0l1 14h6l1-14M10 11v7m4-7v7M5 7h14"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>

          <button className="iconBtn" onClick={doUndo} disabled={undo.length === 0} title="되돌림">
            ↶
          </button>
        <button className="primaryBtn" onClick={() => addPanel("P")}>
          P
        </button>
<button
            className="iconBtn"
            onClick={addSpecialPanel}
            title="스페셜 이미지 패널 추가"
            aria-label="Add special image panel"
          >
            S
          </button>
        </div>
      </div>

      <section className="panelRow" aria-label="Panels">
        {panels.map((p) => (
          <article
            key={p.id}
            className="panel"
            style={{
              ["--panel" as any]: p.color,
              position: "relative",
              ...(p.bgImage
                ? {
                    backgroundImage: `linear-gradient(180deg, rgba(0,0,0,0.62), rgba(0,0,0,0.62)), url(${p.bgImage})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",
                  }
                : {}),
            }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onPanelDrop(p.id)}
          >
            <header className="panelHeader">
              <div className="panelTitleWrap">
                <span className="dot" />
                <input
                  className="panelTitle"
                  value={p.title}
                  onChange={(e) => renamePanel(p.id, e.target.value)}
                />
              </div>

              <div className="panelRight">
                <button
                  className="grabBtn"
                  draggable
                  onDragStart={() => onPanelDragStart(p.id)}
                  title="패널 이동"
                >
                  ⠿
                </button>

                <label className="colorPill" title="패널 색상">
                  <input
                    type="color"
                    className="colorInput"
                    value={p.color}
                    onChange={(e) => setPanelColor(p.id, e.target.value)}
                  />
                </label>

                <button className="dangerBtn" onClick={() => deletePanel(p.id)} title="패널 삭제">
                  X
                </button>
      
        </div>
            </header>

            <div className="panelTools">
              {p.isSpecial ? (
                <div style={{ display: "flex", alignItems: "center", gap: 8, paddingBottom: 10 }}>
                  <label
                    className="secondaryBtn"
                    style={{
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      lineHeight: 1,
                      paddingTop: 0,
                      paddingBottom: 0,
                    }}
                  >
                    img
                    <input
                      type="file"
                      accept="image/*"
                      style={{ display: "none" }}
                      ref={(el) => {
                        specialInputRefs.current[p.id] = el;
                      }}
                      onChange={(e) =>
                        onPickPanelImage(p.id, e.currentTarget.files?.[0] ?? null)
                      }
                    />
                  </label>
                  {p.bgImage ? (
                    <button
                      className="dangerBtn"
                      title="배경 이미지 삭제"
                      aria-label="Remove background image"
                      onClick={() => clearPanelImage(p.id)}
                      style={{ width: 34, height: 34 }}
                    >
                      ×
                    </button>
                  ) : null}
                </div>
              ) : null}

              <TodoComposer onAdd={(t) => addItem(p.id, t)} />
            </div>

            <ul className="list" aria-label={`${p.title} items`}>
              {p.items.map((it) => {
                const hintHere =
                  dropHint?.panelId === p.id && dropHint?.beforeItemId === it.id ? true : false;

                return (
                  <React.Fragment key={it.id}>
                    {hintHere && <div className="dropLine" />}
                    <li
                      className="item"
                      draggable
                      onDragStart={() => onItemDragStart(p.id, it.id)}
                      onDragOver={(e) => {
                        e.preventDefault();
                        onItemDragOver(p.id, it.id);
                      }}
                      onDrop={() => onItemDrop(p.id, it.id)}
                      onDragEnd={onItemDragEnd}
                    >
                      <button
                        className="itemGrab"
                        title={it.done ? "완료됨" : "드래그로 이동"}
                        aria-label="drag handle"
                        style={{
                          display: "grid",
                          placeItems: "center",
                          lineHeight: 0,
                          ...(it.done
                            ? {
                                transform: "scale(0.68)",
                                transformOrigin: "center",
                                background: mixHex(p.color, "#000000", 0.72),
                                border: `1px solid ${mixHex(p.color, "#ffffff", 0.14)}`,
                                color: "rgba(255,255,255,0.92)",
                              }
                            : { color: "rgba(255,255,255,0.70)" }),
                        }}
                      >
                        {it.done ? <CheckMark size={14} /> : <Dots6 size={14} />}
                      </button>

                      <input
                        className="chk"
                        type="checkbox"
                        checked={it.done}
                        onChange={() => toggleItem(p.id, it.id)}
                        aria-label="done"
                      />

                      <div className="itemMain">
                        <input
                          className="itemText"
                          style={{ color: it.done ? "rgba(255,255,255,0.34)" : "var(--text)" }}
                          value={it.text}
                          onChange={(e) => updateItemText(p.id, it.id, e.target.value)}
                        />
                      </div>

                      <div className="itemMeta" style={{ color: it.done ? "rgba(255,255,255,0.30)" : "rgba(255,255,255,0.55)" }}>
                        {formatStamp(it.createdAt)}
                      </div>

                      <button className="xBtn" onClick={() => deleteItem(p.id, it.id)} title="삭제">
                        ×
                      </button>
                    </li>
                  </React.Fragment>
                );
              })}

              {/* drop at end */}
              {dropHint?.panelId === p.id && dropHint?.beforeItemId === null && <div className="dropLine" />}
              <li
                className="endDropZone"
                onDragOver={(e) => {
                  e.preventDefault();
                  onItemDragOver(p.id, null);
                }}
                onDrop={() => onItemDrop(p.id, null)}
              />
            </ul>

            {/* 스페셜 패널 합계 바: 콜론+숫자 항목이 하나라도 있을 때 표시 */}
            {p.isSpecial && (() => {
              const sum = extractPanelSum(p.items);
              if (sum === null) return null;
              return (
                <div className="sumBar">
                  <span className="sumLabel">합계</span>
                  <span className="sumValue">{formatNumber(sum)}</span>
                </div>
              );
            })()}
          </article>
        ))}
      </section>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}

function TodoComposer({ onAdd }: { onAdd: (text: string) => void }) {
  const [v, setV] = useState("");
  return (
    <div className="composer">
      <input
        className="todoInput"
        value={v}
        placeholder="할 일 입력 후 Enter"
        onChange={(e) => setV(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            onAdd(v);
            setV("");
          }
        }}
      />
      <button
        className="secondaryBtn"
        onClick={() => {
          onAdd(v);
          setV("");
        }}
      >
        추가
      </button>
    </div>
  );
}
