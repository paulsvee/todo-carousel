@echo off
cd /d "C:\Users\ntoya\바탕 화면\project"
start "" cmd /k "npm run dev"
timeout /t 2 >nul
start "" "http://localhost:3000"
