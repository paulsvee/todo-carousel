"use client";

/* Paulsvee To do — Trash v5 */

import React, { useCallback } from "react";
import TopNav from "@/components/TopNav";
import {
  trashStore,
  hydrateTrashFromStorage,
  saveTrashToStorage,
  toggleTrashPanel,
  setTrashPanelTitle,
  setTrashPanelColor,
  deleteTrashItem,
  DEFAULT_PANEL_COLOR,
} from "@/store/trashStore";

const formatStampIso = (iso: string) => {
  const d = new Date(iso);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}.${dd} ${hh}:${mi}`;
};

type Snapshot = ReturnType<typeof snapshotPanels>;
function snapshotPanels() {
  return JSON.parse(JSON.stringify(trashStore.panels));
}

export default function TrashPage() {
  const [hydrated, setHydrated] = React.useState(false);
  const [tick, setTick] = React.useState(0);
  const forceRender = useCallback(() => setTick((n) => n + 1), []);

  const [undo, setUndo] = React.useState<Snapshot[]>([]);
  const [toast, setToast] = React.useState<string | null>(null);

  React.useEffect(() => {
    hydrateTrashFromStorage();

    // 레거시 색상 보정
    const legacy = new Set(["#9ca3af", "#6b7280", "#4b5563"]);
    let changed = false;
    for (const p of trashStore.panels) {
      if (legacy.has((p.color || "").toLowerCase())) {
        p.color = DEFAULT_PANEL_COLOR;
        changed = true;
      }
    }
    if (changed) saveTrashToStorage();

    setHydrated(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // 단 한 번만 실행

  if (!hydrated) {
    return (
      <main className="app">
        <div className="topbar">
          <div className="titleBlock">
            <div className="skeletonTitle" />
            <div className="skeletonSub" />
          </div>
        </div>
      </main>
    );
  }

  const panels = trashStore.panels;
  const totalItems = panels.reduce((acc, p) => acc + p.items.length, 0);

  const pushUndo = () => setUndo((prev) => [snapshotPanels(), ...prev].slice(0, 20));

  const doUndo = () => {
    setUndo((prev) => {
      if (!prev.length) return prev;
      const [top, ...rest] = prev;
      trashStore.panels = top as any;
      saveTrashToStorage();
      forceRender();
      setToast("되돌림 완료");
      window.setTimeout(() => setToast(null), 900);
      return rest;
    });
  };

  return (
    <main className="app" data-tick={tick}>
      <TopNav
        current="trash"
        titleValue="휴지통"
        mottoValue="완료된 업무 히스토리 (삭제 아님)"
        titleReadOnly
        mottoReadOnly
        onChangeTitle={() => {}}
        onChangeMotto={() => {}}
      >
        <button className="iconBtn" onClick={doUndo} disabled={undo.length === 0} title="되돌림" aria-label="Undo">↶</button>
        <input className="panelNameInput" value={`총 패널 ${panels.length} · 총 항목 ${totalItems}`} readOnly />
      </TopNav>

      <section className="panelRow" aria-label="Trash panels" style={{ flexWrap: "nowrap", overflowX: "auto" } as any}>
        {panels.length === 0 ? (
          <article className="panel" style={{ ["--panel" as any]: DEFAULT_PANEL_COLOR }}>
            <header className="panelHeader">
              <div className="panelTitleWrap">
                <span className="dot" />
                <input className="panelTitle" value="완료 기록 없음" readOnly />
              </div>
              <div className="panelRight">
                <span className="itemMeta" style={{ opacity: 0.7 }}>아직 이동된 항목이 없어요.</span>
              </div>
            </header>
          </article>
        ) : (
          panels.map((p) => {
            const itemsSorted = [...p.items].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

            return (
              <article key={p.id} className="panel" style={{ ["--panel" as any]: p.color, flex: "0 0 auto" }}>
                <header className="panelHeader">
                  <div className="panelTitleWrap">
                    <span className="dot" />
                    <input
                      className="panelTitle"
                      value={p.title}
                      onChange={(e) => { pushUndo(); setTrashPanelTitle(p.id, e.target.value); forceRender(); }}
                      style={{ fontSize: 14, fontWeight: 700 }}
                    />
                  </div>
                  <div className="panelRight">
                    <label className="colorPill" title="패널 색상">
                      <input
                        type="color"
                        className="colorInput"
                        value={p.color}
                        onChange={(e) => { pushUndo(); setTrashPanelColor(p.id, e.target.value); forceRender(); }}
                      />
                    </label>
                    <button className="iconBtn" type="button" title={p.isCollapsed ? "펼치기" : "접기"}
                      onClick={() => { pushUndo(); toggleTrashPanel(p.id); forceRender(); }}>
                      {p.isCollapsed ? "▾" : "▴"}
                    </button>
                    <span className="itemMeta" style={{ opacity: 0.85 }}>{p.items.length}개</span>
                  </div>
                </header>

                <div className="panelTools" />

                {!p.isCollapsed && (
                  <ul className="list" aria-label={`${p.title} items`}>
                    {itemsSorted.map((it, idx) => {
                      const num = itemsSorted.length - idx;
                      return (
                        <li key={it.id} className="item">
                          <button className="itemGrab" aria-label="history" title="history">•</button>
                          <div className="itemMain">
                            <input className="itemText" value={`${num}. ${it.title}`} readOnly />
                            <div style={{ marginTop: 6, fontSize: 12, opacity: 0.8 }}>
                              <span>{it.categoryName}</span>
                            </div>
                          </div>
                          <div className="itemMeta">{formatStampIso(it.createdAt)}</div>
                          <button className="xBtn" type="button" title="완료 기록 삭제"
                            onClick={() => { pushUndo(); deleteTrashItem(p.id, it.id); forceRender(); setToast("삭제됨 (되돌림 가능)"); window.setTimeout(() => setToast(null), 900); }}>
                            ×
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </article>
            );
          })
        )}
      </section>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}
