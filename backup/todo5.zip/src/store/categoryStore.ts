// categoryStore.ts — 메인/드림 공유 카테고리 스토어

export type Category = {
  id: string;
  name: string;
  createdAt: number;
};

const STORAGE_KEY_CATEGORIES = "paulsvee_categories_v1";

function uid() {
  return (
    (globalThis.crypto?.randomUUID?.() ??
      `id_${Math.random().toString(16).slice(2)}_${Date.now()}`)
  );
}

function canUse() {
  return typeof window !== "undefined";
}

export function loadCategories(): Category[] {
  if (!canUse()) return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CATEGORIES);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr.map((c: any) => ({
      id:        typeof c.id        === "string" ? c.id        : uid(),
      name:      typeof c.name      === "string" ? c.name      : "카테고리",
      createdAt: typeof c.createdAt === "number" ? c.createdAt : Date.now(),
    }));
  } catch {
    return [];
  }
}

export function saveCategories(cats: Category[]) {
  if (!canUse()) return;
  try {
    localStorage.setItem(STORAGE_KEY_CATEGORIES, JSON.stringify(cats));
  } catch {}
}

export function createCategory(name: string): Category {
  return { id: uid(), name, createdAt: Date.now() };
}
