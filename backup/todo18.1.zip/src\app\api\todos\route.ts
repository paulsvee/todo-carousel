import { NextRequest, NextResponse } from "next/server";
import { readFile, writeFile, mkdir } from "fs/promises";
import path from "path";

// ─── 파일 경로 ─────────────────────────────────────────────────────────────────
const DATA_DIR  = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "todos.json");

// data/todos.json 구조:
// { state: AppState | null, categories_main: Category[] }

// ─── CORS ──────────────────────────────────────────────────────────────────────
const CORS_ORIGIN = "http://localhost:3004";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": CORS_ORIGIN,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders() });
}

// ─── GET ───────────────────────────────────────────────────────────────────────

export async function GET() {
  try {
    const raw = await readFile(DATA_FILE, "utf-8");
    return NextResponse.json(JSON.parse(raw), { headers: corsHeaders() });
  } catch {
    // 파일 없음 → 빈 초기 상태 반환 (클라이언트가 localStorage에서 마이그레이션)
    return NextResponse.json(
      { state: null, categories_main: [] },
      { headers: corsHeaders() }
    );
  }
}

// ─── POST ──────────────────────────────────────────────────────────────────────
// Body: { state: AppState, categories_main: Category[] }

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    await mkdir(DATA_DIR, { recursive: true });
    await writeFile(DATA_FILE, JSON.stringify(body, null, 2), "utf-8");
    return NextResponse.json({ ok: true }, { headers: corsHeaders() });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: String(e) },
      { status: 500, headers: corsHeaders() }
    );
  }
}
