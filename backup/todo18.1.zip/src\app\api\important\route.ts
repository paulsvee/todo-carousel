import { NextRequest, NextResponse } from "next/server";

// ─── CORS ─────────────────────────────────────────────────────────────────────

const CORS_ORIGIN = "http://localhost:3004";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": CORS_ORIGIN,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders() });
}

// ─── Types ────────────────────────────────────────────────────────────────────

type TodoItem = {
  id: string;
  text: string;
  done: boolean;
  createdAt: number;
};

type Panel = {
  id: string;
  title: string;
  color: string;
  createdAt: number;
  items: TodoItem[];
  categoryIds: string[];
  categoryAssignedAt?: number | null;
  isSpecial?: boolean;
  bgImage?: string | null;
};

type Category = {
  id: string;
  name: string;
  createdAt: number;
};

// ─── In-memory store ──────────────────────────────────────────────────────────
// Next.js dev 서버는 모듈을 캐시하므로 재시작 전까지 유지됨

let cachedPanels: Panel[] = [];
let lastUpdated: number | null = null;

// ─── GET ──────────────────────────────────────────────────────────────────────

export async function GET() {
  return NextResponse.json(
    { panels: cachedPanels, lastUpdated },
    { headers: corsHeaders() }
  );
}

// ─── POST ─────────────────────────────────────────────────────────────────────
// Body: { panels: Panel[], categories: Category[] }
// 클라이언트가 localStorage 에서 읽어서 보내줌

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const panels: Panel[]     = Array.isArray(body.panels)     ? body.panels     : [];
    const categories: Category[] = Array.isArray(body.categories) ? body.categories : [];

    // "중요" 카테고리 id 찾기
    const importantCat = categories.find((c) => c.name === "중요");
    if (!importantCat) {
      // 카테고리가 없으면 빈 배열로 초기화
      cachedPanels = [];
      lastUpdated  = Date.now();
      return NextResponse.json(
        { ok: true, message: '"중요" 카테고리 없음', panels: [] },
        { headers: corsHeaders() }
      );
    }

    // 해당 id 가 categoryIds 에 포함된 패널만 필터
    cachedPanels = panels.filter((p) =>
      Array.isArray(p.categoryIds) && p.categoryIds.includes(importantCat.id)
    );
    lastUpdated = Date.now();

    return NextResponse.json(
      { ok: true, panels: cachedPanels },
      { headers: corsHeaders() }
    );
  } catch {
    return NextResponse.json(
      { ok: false, error: "invalid body" },
      { status: 400, headers: corsHeaders() }
    );
  }
}
