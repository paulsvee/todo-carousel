import type { DoneTask } from "./doneTask";

export type TrashPanel = {
  id: string;

  // 예: "260201-260206" (YYMMDD-YYMMDD)
  title: string;

  // 패널 묶음 구간
  fromDate: string; // ISO
  toDate: string; // ISO

  // 패널 색상 (hex)
  color: string;

  items: DoneTask[];

  // 패널 접기/펼치기
  isCollapsed: boolean;

  // 사용자가 제목을 수정했는지 여부 (수정 후엔 자동 타이틀 업데이트 안 함)
  isTitleCustom: boolean;
};
