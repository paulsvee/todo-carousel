import type { TrashPanel } from "@/types/trashPanel";
import type { DoneTask } from "@/types/doneTask";

type TrashStoreState = {
  panels: TrashPanel[];
  _hydrated?: boolean;
};

const STORAGE_KEY_TRASH = "paulsvee_todo_trash_v1";

// ✅ 30개씩 묶음
const MAX_ITEMS_PER_PANEL = 30;

// ✅ 메인 패널 기본 컬러와 동일하게
export const DEFAULT_PANEL_COLOR = "#7c98ff";

export const trashStore: TrashStoreState = {
  panels: [],
  _hydrated: false,
};

function canUseStorage() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function safeParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function hydrateTrashFromStorage() {
  if (trashStore._hydrated) return;
  trashStore._hydrated = true;

  if (!canUseStorage()) return;

  const data = safeParse<any>(localStorage.getItem(STORAGE_KEY_TRASH));
  if (!data || typeof data !== "object") return;

  const panelsIn = Array.isArray(data.panels) ? data.panels : [];
  const panels: TrashPanel[] = panelsIn
    .map((p: any) => {
      if (!p) return null;

      const itemsIn = Array.isArray(p.items) ? p.items : [];
      const items: DoneTask[] = itemsIn
        .map((t: any) => {
          if (!t) return null;
          return {
            id: typeof t.id === "string" ? t.id : crypto.randomUUID(),
            title: typeof t.title === "string" ? t.title : "",
            createdAt: typeof t.createdAt === "string" ? t.createdAt : new Date().toISOString(),
            doneAt: typeof t.doneAt === "string" ? t.doneAt : new Date().toISOString(),
            categoryName: typeof t.categoryName === "string" ? t.categoryName : "",
            originPanelTitle: typeof t.originPanelTitle === "string" ? t.originPanelTitle : "",
          } as DoneTask;
        })
        .filter(Boolean) as DoneTask[];

      return {
        id: typeof p.id === "string" ? p.id : crypto.randomUUID(),
        title: typeof p.title === "string" ? p.title : "000000-000000",
        fromDate: typeof p.fromDate === "string" ? p.fromDate : (items[0]?.createdAt ?? new Date().toISOString()),
        toDate: typeof p.toDate === "string" ? p.toDate : (items[0]?.createdAt ?? new Date().toISOString()),
        color: typeof p.color === "string" ? p.color : DEFAULT_PANEL_COLOR,
        items,
        isCollapsed: !!p.isCollapsed,
        isTitleCustom: !!p.isTitleCustom,
      } as TrashPanel;
    })
    .filter(Boolean) as TrashPanel[];

  trashStore.panels = panels;
}

export function saveTrashToStorage() {
  if (!canUseStorage()) return;
  try {
    localStorage.setItem(STORAGE_KEY_TRASH, JSON.stringify({ panels: trashStore.panels }));
  } catch {
    // ignore
  }
}

function yymmdd(iso: string) {
  const d = new Date(iso);
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yy}${mm}${dd}`;
}

function autoTitle(fromIso: string, toIso: string) {
  return `${yymmdd(fromIso)}-${yymmdd(toIso)}`;
}

function minIso(a: string, b: string) {
  return new Date(a).getTime() <= new Date(b).getTime() ? a : b;
}
function maxIso(a: string, b: string) {
  return new Date(a).getTime() >= new Date(b).getTime() ? a : b;
}

function createPanel(basisIso: string): TrashPanel {
  const title = autoTitle(basisIso, basisIso);
  return {
    id: crypto.randomUUID(),
    title,
    fromDate: basisIso,
    toDate: basisIso,
    color: DEFAULT_PANEL_COLOR,
    items: [],
    isCollapsed: false,
    isTitleCustom: false,
  };
}

function updateAutoTitle(panel: TrashPanel) {
  if (!panel.isTitleCustom) {
    panel.title = autoTitle(panel.fromDate, panel.toDate);
  }
}

function ensureHydrated() {
  hydrateTrashFromStorage();
}

export function addDoneTaskToTrash(doneTask: DoneTask) {
  ensureHydrated();

  const panels = trashStore.panels;
  let currentPanel = panels[0];

  // ✅ 기간/타이틀/정렬 기준은 "원래 생성일(createdAt)"
  const basisIso = doneTask.createdAt || doneTask.doneAt;

  if (!currentPanel || currentPanel.items.length >= MAX_ITEMS_PER_PANEL) {
    currentPanel = createPanel(basisIso);
    panels.unshift(currentPanel);
  }

  currentPanel.fromDate = currentPanel.fromDate ? minIso(currentPanel.fromDate, basisIso) : basisIso;
  currentPanel.toDate = currentPanel.toDate ? maxIso(currentPanel.toDate, basisIso) : basisIso;
  updateAutoTitle(currentPanel);

  currentPanel.items.push(doneTask);
  saveTrashToStorage();
}

export function toggleTrashPanel(panelId: string) {
  ensureHydrated();
  const panel = trashStore.panels.find((p) => p.id === panelId);
  if (panel) {
    panel.isCollapsed = !panel.isCollapsed;
    saveTrashToStorage();
  }
}

export function setTrashPanelTitle(panelId: string, title: string) {
  ensureHydrated();
  const panel = trashStore.panels.find((p) => p.id === panelId);
  if (!panel) return;
  panel.title = title;
  panel.isTitleCustom = true;
  saveTrashToStorage();
}

export function setTrashPanelColor(panelId: string, color: string) {
  ensureHydrated();
  const panel = trashStore.panels.find((p) => p.id === panelId);
  if (!panel) return;
  panel.color = color;
  saveTrashToStorage();
}

export function deleteTrashItem(panelId: string, itemId: string) {
  ensureHydrated();
  const panel = trashStore.panels.find((p) => p.id === panelId);
  if (!panel) return;

  panel.items = panel.items.filter((it) => it.id !== itemId);

  if (panel.items.length === 0) {
    trashStore.panels = trashStore.panels.filter((p) => p.id !== panelId);
  }

  saveTrashToStorage();
}
