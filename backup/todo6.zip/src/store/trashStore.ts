import type { TrashPanel } from "@/types/trashPanel";
import type { DoneTask } from "@/types/doneTask";

type TrashStoreState = {
  panels: TrashPanel[];
  _hydrated: boolean;
};

const STORAGE_KEY_TRASH = "paulsvee_todo_trash_v1";
const MAX_ITEMS_PER_PANEL = 30;
export const DEFAULT_PANEL_COLOR = "#7c98ff";

export const trashStore: TrashStoreState = {
  panels: [],
  _hydrated: false,
};

function canUseStorage() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function safeParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try { return JSON.parse(raw) as T; } catch { return null; }
}

function parsePanels(data: any): TrashPanel[] {
  if (!data || typeof data !== "object") return [];
  const panelsIn = Array.isArray(data.panels) ? data.panels : [];
  return panelsIn.map((p: any): TrashPanel | null => {
    if (!p) return null;
    const items: DoneTask[] = (Array.isArray(p.items) ? p.items : [])
      .map((t: any): DoneTask | null => {
        if (!t) return null;
        return {
          id: typeof t.id === "string" ? t.id : crypto.randomUUID(),
          title: typeof t.title === "string" ? t.title : "",
          createdAt: typeof t.createdAt === "string" ? t.createdAt : new Date().toISOString(),
          doneAt: typeof t.doneAt === "string" ? t.doneAt : new Date().toISOString(),
          categoryName: typeof t.categoryName === "string" ? t.categoryName : "",
          originPanelTitle: typeof t.originPanelTitle === "string" ? t.originPanelTitle : "",
        };
      }).filter(Boolean) as DoneTask[];
    return {
      id: typeof p.id === "string" ? p.id : crypto.randomUUID(),
      title: typeof p.title === "string" ? p.title : "000000-000000",
      fromDate: typeof p.fromDate === "string" ? p.fromDate : (items[0]?.createdAt ?? new Date().toISOString()),
      toDate: typeof p.toDate === "string" ? p.toDate : (items[0]?.createdAt ?? new Date().toISOString()),
      color: typeof p.color === "string" ? p.color : DEFAULT_PANEL_COLOR,
      items,
      isCollapsed: !!p.isCollapsed,
      isTitleCustom: !!p.isTitleCustom,
    };
  }).filter(Boolean) as TrashPanel[];
}

// ✅ trash 페이지 진입 전용 — 항상 최신 데이터로 강제 로드, _hydrated도 리셋
export function reloadTrashFromStorage() {
  if (!canUseStorage()) return;
  const data = safeParse<any>(localStorage.getItem(STORAGE_KEY_TRASH));
  trashStore.panels = parsePanels(data);
  trashStore._hydrated = true;
}

// ✅ 내부 액션 전용 — 이미 hydrate된 경우 스킵 (panels 덮어쓰기 방지)
function ensureHydrated() {
  if (trashStore._hydrated) return;
  trashStore._hydrated = true;
  if (!canUseStorage()) return;
  const data = safeParse<any>(localStorage.getItem(STORAGE_KEY_TRASH));
  trashStore.panels = parsePanels(data);
}

export function saveTrashToStorage() {
  if (!canUseStorage()) return;
  try {
    localStorage.setItem(STORAGE_KEY_TRASH, JSON.stringify({ panels: trashStore.panels }));
  } catch {}
}

function yymmdd(iso: string) {
  const d = new Date(iso);
  return `${String(d.getFullYear()).slice(2)}${String(d.getMonth()+1).padStart(2,"0")}${String(d.getDate()).padStart(2,"0")}`;
}
function autoTitle(f: string, t: string) { return `${yymmdd(f)}-${yymmdd(t)}`; }
function minIso(a: string, b: string) { return new Date(a).getTime() <= new Date(b).getTime() ? a : b; }
function maxIso(a: string, b: string) { return new Date(a).getTime() >= new Date(b).getTime() ? a : b; }

function createPanel(basisIso: string): TrashPanel {
  return {
    id: crypto.randomUUID(),
    title: autoTitle(basisIso, basisIso),
    fromDate: basisIso, toDate: basisIso,
    color: DEFAULT_PANEL_COLOR,
    items: [], isCollapsed: false, isTitleCustom: false,
  };
}

function updateAutoTitle(panel: TrashPanel) {
  if (!panel.isTitleCustom) panel.title = autoTitle(panel.fromDate, panel.toDate);
}

export function addDoneTaskToTrash(doneTask: DoneTask) {
  ensureHydrated();
  const panels = trashStore.panels;
  const basisIso = doneTask.createdAt || doneTask.doneAt;
  let current = panels[0];
  if (!current || current.items.length >= MAX_ITEMS_PER_PANEL) {
    current = createPanel(basisIso);
    panels.unshift(current);
  }
  current.fromDate = current.fromDate ? minIso(current.fromDate, basisIso) : basisIso;
  current.toDate   = current.toDate   ? maxIso(current.toDate,   basisIso) : basisIso;
  updateAutoTitle(current);
  current.items.push(doneTask);
  saveTrashToStorage();
}

export function toggleTrashPanel(panelId: string) {
  ensureHydrated();
  const p = trashStore.panels.find((x) => x.id === panelId);
  if (p) { p.isCollapsed = !p.isCollapsed; saveTrashToStorage(); }
}

export function setTrashPanelTitle(panelId: string, title: string) {
  ensureHydrated();
  const p = trashStore.panels.find((x) => x.id === panelId);
  if (!p) return;
  p.title = title; p.isTitleCustom = true; saveTrashToStorage();
}

export function setTrashPanelColor(panelId: string, color: string) {
  ensureHydrated();
  const p = trashStore.panels.find((x) => x.id === panelId);
  if (!p) return;
  p.color = color; saveTrashToStorage();
}

export function deleteTrashItem(panelId: string, itemId: string) {
  ensureHydrated();
  const p = trashStore.panels.find((x) => x.id === panelId);
  if (!p) return;
  p.items = p.items.filter((it) => it.id !== itemId);
  if (p.items.length === 0) trashStore.panels = trashStore.panels.filter((x) => x.id !== panelId);
  saveTrashToStorage();
}
