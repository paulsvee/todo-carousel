"use client";

/* Paulsvee To do — Trash v6 (TopNav applied) */

import React from "react";
import TopNav from "@/components/TopNav";
import {
  trashStore,
  reloadTrashFromStorage,
  saveTrashToStorage,
  toggleTrashPanel,
  setTrashPanelTitle,
  setTrashPanelColor,
  deleteTrashItem,
  DEFAULT_PANEL_COLOR,
} from "@/store/trashStore";

const formatStampIso = (iso: string) => {
  const d = new Date(iso);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${mm}.${dd} ${hh}:${mi}`;
};

type Snapshot = ReturnType<typeof snapshotPanels>;
function snapshotPanels() {
  return JSON.parse(JSON.stringify(trashStore.panels));
}

export default function TrashPage() {
  const [, forceRender] = React.useReducer((x) => x + 1, 0);

  const [undo, setUndo] = React.useState<Snapshot[]>([]);
  const [toast, setToast] = React.useState<string | null>(null);

  React.useEffect(() => {
    // ✅ 마지막 페이지 기록

    // ✅ persistence hydrate
    reloadTrashFromStorage();

    // ✅ 예전 회색 계열 기본색은 메인 기본색으로 보정
    const legacy = new Set(["#9ca3af", "#6b7280", "#4b5563"]);
    let changed = false;
    for (const p of trashStore.panels) {
      if (legacy.has((p.color || "").toLowerCase())) {
        p.color = DEFAULT_PANEL_COLOR;
        changed = true;
      }
    }
    if (changed) saveTrashToStorage();

    forceRender();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const panels = trashStore.panels;
  const totalItems = panels.reduce((acc, p) => acc + p.items.length, 0);

  const pushUndo = () => setUndo((prev) => [snapshotPanels(), ...prev].slice(0, 20));

  const doUndo = () => {
    setUndo((prev) => {
      if (prev.length === 0) return prev;
      const [top, ...rest] = prev;
      trashStore.panels = top as any;
      saveTrashToStorage();
      forceRender();
      setToast("되돌림 완료");
      window.setTimeout(() => setToast(null), 900);
      return rest;
    });
  };

  return (
    <main className="app">
      <TopNav
        current="trash"
        titleValue="휴지통"
        mottoValue="완료된 업무 히스토리 (삭제 아님)"
        titleReadOnly
        mottoReadOnly
        onChangeTitle={() => {}}
        onChangeMotto={() => {}}
      >
        <button className="iconBtn" onClick={doUndo} disabled={undo.length === 0} title="되돌림" aria-label="Undo">
          ↶
        </button>

        <input className="panelNameInput" value={`총 패널 ${panels.length} · 총 항목 ${totalItems}`} readOnly />
      </TopNav>

      {/* 패널 크기: 메인 CSS 유지 + 줄바꿈만 막기 */}
      <section className="panelRow" aria-label="Trash panels" style={{ flexWrap: "nowrap", overflowX: "auto" } as any}>
        {panels.length === 0 ? (
          <article className="panel" style={{ ["--panel" as any]: DEFAULT_PANEL_COLOR, flex: "0 0 auto" }}>
            <header className="panelHeader">
              <div className="panelTitleWrap">
                <span className="dot" />
                <input className="panelTitle" value="완료 기록 없음" readOnly />
              </div>
              <div className="panelRight">
                <span className="itemMeta" style={{ opacity: 0.7 }}>
                  아직 이동된 항목이 없어요.
                </span>
              </div>
            </header>
          </article>
        ) : (
          panels.map((p) => {
            const itemsSorted = [...p.items].sort(
              (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            );

            return (
              <article key={p.id} className="panel" style={{ ["--panel" as any]: p.color, flex: "0 0 auto" }}>
                <header className="panelHeader">
                  <div className="panelTitleWrap">
                    <span className="dot" />
                    {/* 타이틀 크기 반 정도로 ↓ (bold 유지) */}
                    <input
                      className="panelTitle"
                      value={p.title}
                      onChange={(e) => {
                        pushUndo();
                        setTrashPanelTitle(p.id, e.target.value);
                        forceRender();
                      }}
                      style={{ fontSize: 14, fontWeight: 700 }}
                      aria-label="trash panel title"
                    />
                  </div>

                  <div className="panelRight">
                    <label className="colorPill" title="패널 색상">
                      <input
                        type="color"
                        className="colorInput"
                        value={p.color}
                        onChange={(e) => {
                          pushUndo();
                          setTrashPanelColor(p.id, e.target.value);
                          forceRender();
                        }}
                      />
                    </label>

                    <button
                      className="iconBtn"
                      type="button"
                      title={p.isCollapsed ? "펼치기" : "접기"}
                      onClick={() => {
                        pushUndo();
                        toggleTrashPanel(p.id);
                        forceRender();
                      }}
                    >
                      {p.isCollapsed ? "▾" : "▴"}
                    </button>

                    <span className="itemMeta" style={{ opacity: 0.85 }}>
                      {p.items.length}개
                    </span>
                  </div>
                </header>

                <div className="panelTools" />

                {!p.isCollapsed && (
                  <ul className="list" aria-label={`${p.title} items`}>
                    {itemsSorted.map((it, idx) => {
                      // 위가 가장 큰 숫자
                      const num = itemsSorted.length - idx;

                      return (
                        <li key={it.id} className="item">
                          <button className="itemGrab" aria-label="history" title="history">
                            •
                          </button>

                          <div className="itemMain">
                            {/* 넘버링을 타이틀 앞에 */}
                            <input className="itemText" value={`${num}. ${it.title}`} readOnly />

                            {/* 카테고리 라벨 없이 값만 */}
                            <div style={{ marginTop: 6, fontSize: 12, opacity: 0.8 }}>
                              <span>{it.categoryName}</span>
                            </div>
                          </div>

                          <div className="itemMeta">{formatStampIso(it.createdAt)}</div>

                          <button
                            className="xBtn"
                            type="button"
                            title="완료 기록 삭제"
                            onClick={() => {
                              pushUndo();
                              deleteTrashItem(p.id, it.id);
                              forceRender();
                              setToast("삭제됨 (되돌림 가능)");
                              window.setTimeout(() => setToast(null), 900);
                            }}
                          >
                            ×
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </article>
            );
          })
        )}
      </section>

      {toast && <div className="toast">{toast}</div>}
    </main>
  );
}
