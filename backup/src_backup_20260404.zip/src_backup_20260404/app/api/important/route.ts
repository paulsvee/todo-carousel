import { NextResponse } from "next/server";
import { readCategories, readPanels } from "@/lib/db";

// ─── CORS ─────────────────────────────────────────────────────────────────────
const CORS_ORIGIN = "http://localhost:3004";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": CORS_ORIGIN,
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders() });
}

// ─── GET ──────────────────────────────────────────────────────────────────────
// "중요" 카테고리에 속한 패널만 반환

export async function GET() {
  try {
    const categories = readCategories("main");
    const importantCat = categories.find((c) => c.name === "중요");

    if (!importantCat) {
      return NextResponse.json(
        { panels: [], lastUpdated: null },
        { headers: corsHeaders() }
      );
    }

    const allPanels = readPanels("main");
    const panels = allPanels.filter((p) =>
      Array.isArray(p.categoryIds) && p.categoryIds.includes(importantCat.id)
    );

    return NextResponse.json(
      { panels, lastUpdated: Date.now() },
      { headers: corsHeaders() }
    );
  } catch (e) {
    return NextResponse.json(
      { panels: [], lastUpdated: null, error: String(e) },
      { status: 500, headers: corsHeaders() }
    );
  }
}
